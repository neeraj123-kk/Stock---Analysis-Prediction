Copy over a csv file containing the data.

To run: ``` python StockPredictPrices.py ```

then follow instructions. 
