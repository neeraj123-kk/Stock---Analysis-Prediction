To run: ``` python QMAScreener ```



You can modify two variables, ```numberOfStocks``` and ```rangeResistance```. 
