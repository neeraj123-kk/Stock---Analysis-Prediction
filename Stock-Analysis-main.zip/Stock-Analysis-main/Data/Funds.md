|  Fund Category 	|   Benchmark 	|  % of Funds that outperformed their benchmark for 3 years	| % of Funds that outperformed in subsequent year	| % of Funds that outperformed for 2 subsequent years 	| % of Funds that outperformed for 2 subsequent years 	|
|---	|---	|---	|---	|---	|---	|
|  Large Cap 	|  S&P 500 	|  30.83% 	|  33.93% 	|  13.62% 	|  5.17% 	|
|  Mid Cap 	|  S&P MidCap400 	|  25.65% 	|  30.39% 	|  10.35% 	|  3.24% 	|
|  Small-Cap 	|  S&P SmallCap 600 	|   30.58%	|   35.25%	|  13.30% 	|  4.60% 	|
|  Int'l 	|  S&P 700 	|  23.89% 	|  36.68% 	|  15.66% 	|  6.88% 	|
|  Emerging Markets 	|   S&P/IFCI Composite	|  25.24% 	|  38.39% 	|  15.48% 	|  5.22% 	|
