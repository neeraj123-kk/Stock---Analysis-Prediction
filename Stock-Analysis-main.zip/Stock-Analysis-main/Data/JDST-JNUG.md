
# JDST

## Observable Correlation

1. If DXY is bullish, JDST is bullish

      a. If DXY is bearish, JDST is bearish

2. XAUUSD is bearish, JDST is bullish

      a. XAUUSD is bullish, JDST is bearish

3. USD/JPY & Gold are inverse. (Gold = XAUUSD)
