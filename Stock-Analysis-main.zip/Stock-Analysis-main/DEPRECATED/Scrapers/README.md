To run: ``` python 'Single Stock Scraper.py' ```
